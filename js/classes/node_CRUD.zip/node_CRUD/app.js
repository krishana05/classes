const express = require("express");
const mongoose = require("mongoose");
const path = require("path");
const bodyParser = require("body-parser");
const app = express();
const cors = require("cors");

// connect to database
mongoose.connect(
  "mongodb+srv://aparnacp:mn1rvana80@besantexercises-sqxgk.azure.mongodb.net/test?retryWrites=true&w=majority",
  {
    useNewUrlParser: true
  }
);

app.use(express.static(path.join(__dirname, "static")));

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
//enable CORS
app.use(cors());

const User = require("./models/users");

//create
app.post("/user", (req, res) => {
  console.log(req.body);
  const user = new User({
    _id: new mongoose.Types.ObjectId(),
    name: req.body.name,
    age: req.body.age,
    email: req.body.email
  });
  //   save the data in db
  user
    .save()
    .then(result => {
      // console.log(result);
      console.log("data posted sucessfuly");
      res.send(user);
    })
    .catch(err => {
      console.log(err);
    });
});

app.get("/getUser/:id", (req, res) => {
  User.findById(req.params.id)
    .exec()
    .then(result => {
      if (result[0] != null) res.sendStatus(200).send(result);
      else res.sendStatus(404).send("user found");
    })
    .catch(result => {
      res.send(result);
    });
});

//fetch data from db using Id
// app.get('/getUser/:id',(req,res)=>{
//     User.findById(req.params.id).exec().then(result=>{
//         if(result[0]!=null)
//         res.sendStatus(200).send(result)
//         else
//         res.sendStatus(404).send('user found')
//     }).catch(err=>{
//         res.send(err)
//     })
// })

// get all

app.get("/getUser", (req, res) => {
  User.find()
    .exec()
    .then(result => {
      console.log(result);
      res.send(result);
    })
    .catch(result => {
      res.send(result);
    });
});

//delete

app.delete("/deleteUser/:userId", (req, res) => {
  const id = req.params.userId;
  User.deleteOne({ _id: id })
    .exec()
    .then(result => {
      res.status(200).json(result);
    })
    .catch(err => {
      res.status(500).json({ error: err });
    });
});

//update

app.put("/updateUser/:userId", (req, res) => {
  const id = req.params.userId;
  User.update({ _id: id }, { $set: req.body })
    .exec()
    .then(result => {
      res.status(200).json(result);
    })
    .catch(err => {
      res.status(500).json({ error: err });
    });
});

//listening
app.listen(3000, () => {
  console.log("server is running on 3000");
});
