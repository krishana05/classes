import { Component, OnInit, Input, OnChanges, OnDestroy } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { SharedService } from "../shared.service";
@Component({
  selector: "app-profile",
  templateUrl: "./profile.component.html",
  styleUrls: ["./profile.component.css"]
})
export class ProfileComponent implements OnInit, OnChanges, OnDestroy {
  constructor(private route: ActivatedRoute, private service: SharedService) {
    console.log("Constructor");
  }
  name: string;
  @Input("inputData") inputData;
  ngOnChanges(changesObj) {
    console.log("ngOnChanges", changesObj);
  }
  ngOnInit() {
    console.log("ngOnInit");
    // console.log("profile component");
    // console.log(this.route.params);
    this.route.params.subscribe(value => {
      // console.log(value.name);
      this.name = value.name;
      // if(this.name == "Tom"){
      //   //load Tom Component

      // }
      // if(this.name == "Cat"){
      //   //load Cat Component

      // }
    });
    // console.log("input data", this.inputData);
  }
  getData(res) {
    // console.log(this.service.getData());
    console.log(res);
  }
  ngOnDestroy() {
    console.log("ngOnDestroy");
  }
}
