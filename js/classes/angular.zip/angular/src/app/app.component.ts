import { Component, OnInit } from "@angular/core";

import { FormGroup, FormControl } from "@angular/forms";
import { SharedService } from "./shared.service";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent implements OnInit {
  title = "AngularApps";
  name: string;
  date = new Date();
  someArray = ["A", "B", "C", "D"];
  city = new FormControl("");
  profile = new FormGroup({
    firstName: new FormControl(""),
    lastName: new FormControl("")
  });
  postProfile = new FormGroup({
    name: new FormControl(""),
    age: new FormControl(""),
    email: new FormControl("")
  });
  constructor(private service: SharedService) {
    // console.log("Constructor");
  }
  ngOnInit() {
    // console.log("Ng Onint");
    this.service.getDataFromAPI().subscribe(data => {
      console.log(data);
    });
  }
  change() {
    this.someArray.push("E");
    console.log(this.someArray);
  }
  submitForm() {
    console.log(this.profile);
    console.log(this.profile.value);
    // if (!this.profile.valid) alert("Please enter first name");
  }
  postProfileData() {
    console.log(this.postProfile.value);
    this.service.postData(this.postProfile.value).subscribe(res => {
      console.log(res);
    });
  }
  updateItem() {
    const id = "5db554f6d395bf2b64207ffc";
    this.service
      .updateData(id, {
        name: "Robert Pascal",
        age: 30,
        email: "john@gmail.com"
      })
      .subscribe(res => {
        console.log(res);
      });
  }
  deleteItem() {
    const id = "5d4fa12ff1fb4549cb400dea";
    this.service.deleteData(id).subscribe(res => {
      console.log(res);
    });
  }
}
