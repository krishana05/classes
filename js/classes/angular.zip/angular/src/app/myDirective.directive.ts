import { Directive, ElementRef } from "@angular/core";

@Directive({
  // element, class, attribute and type
  selector: "highlight"
  //   selector: ".highlight"
  //   selector: "[highlight]"
  // selector: "input[type='text']"
})
export class MyDirective {
  constructor(private el: ElementRef) {
    el.nativeElement.style.backgroundColor = "yellow";
  }
}
