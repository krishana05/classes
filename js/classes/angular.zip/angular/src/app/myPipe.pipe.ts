import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
  name: "myPipe"
})
export class MyPipe implements PipeTransform {
  transform(input: any, args: any) {
    console.log(input);
    return input * args;
  }
}
