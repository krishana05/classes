import { Component, Input, OnInit, EventEmitter, Output } from "@angular/core";
import { Router } from "@angular/router";
import { SharedService } from "../shared.service";

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.css"]
  // [
  //     `li
  //     {
  //         color:red;
  //     }
  //     li{
  //         color : orange;
  //     }
  //     .inputBox
  //     {
  //         background-color : orange;
  //     }
  //     .para
  //     {
  //         background-color : yellow;
  //     }
  //     .redColor
  //     {
  //         background-color : red;
  //     }
  //     .blueColor
  //     {
  //         background-color : blue;
  //     }
  //     `
  // ]
})
export class HomeComponent implements OnInit {
  @Input("result") result;
  @Output() dataSent = new EventEmitter<any>();
  constructor(private router: Router, private service: SharedService) {}

  name = "Jefferey Archer";
  address = "England";
  flag = false;
  selectedState: any;
  selectedCity: string;
  // data = ["Bangalore","Hyd","ND","Che","Tel"];
  data = [
    {
      state: "Karnataka",
      city: "Bangalore"
    },
    {
      state: " Delhi ",
      city: " New Delhi"
    },
    {
      state: " WB",
      city: " Kol"
    },
    {
      state: " Tel ",
      city: " Hyd"
    },
    {
      state: " MP ",
      city: "Bho"
    }
  ];
  // input = "";
  // disable(){
  //     if(this.flag) this.flag=false;
  //     else this.flag= true;
  //     // this.flag? (this.flag=false) :(this.flag=true);
  // }
  //    Showlist(){
  //         this.flag = true;

  //     }
  // Show(){
  //     if(this.flag) this.flag = false;
  //     else this.flag = true;
  // }
  ngOnInit() {
    // console.log("result", this.result);
  }
  saveData() {
    // this.service.saveData(this.data);
    console.log("event emitted");
    this.dataSent.emit(this.data);
  }
  getData() {
    this.service.getDataFromAPI().subscribe(res => {
      console.log(res);
    });
  }
  stateSelected() {
    console.log(this.selectedState);
    this.data.forEach(element => {
      if (element.state == this.selectedState) this.selectedCity = element.city;
    });
    console.log(this.selectedCity);
  }
  goToProfile(name) {
    this.router.navigate(["/myProfile/" + name]);
  }
}
