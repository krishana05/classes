import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";

@Injectable({
  providedIn: "root"
})
export class SharedService {
  constructor(private http: HttpClient) {}
  result: any;
  saveData(data) {
    console.log("data saved successfully", data);
    this.result = data;
  }
  getData() {
    return this.result;
  }
  getDataFromAPI() {
    return this.http.get("http://localhost:3000/getUser");
  }
  postData(data) {
    return this.http.post("http://localhost:3000/user", data);
  }
  updateData(id, data) {
    return this.http.put("http://localhost:3000/updateUser/" + id, data);
  }
  deleteData(id) {
    return this.http.delete("http://localhost:3000/deleteUser/" + id);
  }
}
